<?php
/**
 * @package WordPress
 * @subpackage WP-Skeleton
 */
?>
<?php get_template_part( 'index', 'single' ); ?> 
    
                               